package montaje;

public class Taller {
	
	static final int BICICLETAS = 5;
	static final int FASES = 3;
	
	public static void main(String[]args) {
	
		
	}

}
